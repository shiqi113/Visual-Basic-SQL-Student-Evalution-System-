﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmstudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lbllecturerid = New System.Windows.Forms.Label()
        Me.txtclearexplanation = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtfairness = New System.Windows.Forms.TextBox()
        Me.txtresponsibility = New System.Windows.Forms.TextBox()
        Me.txtquality = New System.Windows.Forms.TextBox()
        Me.cbocoursetid = New System.Windows.Forms.ComboBox()
        Me.txtpunctuality = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtpreparation = New System.Windows.Forms.TextBox()
        Me.txtinteresting = New System.Windows.Forms.TextBox()
        Me.txtvoice = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnsubmit = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(267, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(298, 46)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Welcome Student"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbllecturerid)
        Me.GroupBox1.Controls.Add(Me.txtclearexplanation)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txtfairness)
        Me.GroupBox1.Controls.Add(Me.txtresponsibility)
        Me.GroupBox1.Controls.Add(Me.txtquality)
        Me.GroupBox1.Controls.Add(Me.cbocoursetid)
        Me.GroupBox1.Controls.Add(Me.txtpunctuality)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtpreparation)
        Me.GroupBox1.Controls.Add(Me.txtinteresting)
        Me.GroupBox1.Controls.Add(Me.txtvoice)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(184, 58)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(468, 518)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Course Evaluation"
        '
        'lbllecturerid
        '
        Me.lbllecturerid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbllecturerid.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllecturerid.Location = New System.Drawing.Point(207, 65)
        Me.lbllecturerid.Name = "lbllecturerid"
        Me.lbllecturerid.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbllecturerid.Size = New System.Drawing.Size(196, 26)
        Me.lbllecturerid.TabIndex = 21
        '
        'txtclearexplanation
        '
        Me.txtclearexplanation.Location = New System.Drawing.Point(207, 446)
        Me.txtclearexplanation.Name = "txtclearexplanation"
        Me.txtclearexplanation.Size = New System.Drawing.Size(196, 30)
        Me.txtclearexplanation.TabIndex = 15
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(20, 66)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(147, 25)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Lecturer ID:"
        '
        'txtfairness
        '
        Me.txtfairness.Location = New System.Drawing.Point(207, 393)
        Me.txtfairness.Name = "txtfairness"
        Me.txtfairness.Size = New System.Drawing.Size(196, 30)
        Me.txtfairness.TabIndex = 14
        '
        'txtresponsibility
        '
        Me.txtresponsibility.Location = New System.Drawing.Point(207, 346)
        Me.txtresponsibility.Name = "txtresponsibility"
        Me.txtresponsibility.Size = New System.Drawing.Size(196, 30)
        Me.txtresponsibility.TabIndex = 13
        '
        'txtquality
        '
        Me.txtquality.Location = New System.Drawing.Point(207, 295)
        Me.txtquality.Name = "txtquality"
        Me.txtquality.Size = New System.Drawing.Size(196, 30)
        Me.txtquality.TabIndex = 12
        '
        'cbocoursetid
        '
        Me.cbocoursetid.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbocoursetid.FormattingEnabled = True
        Me.cbocoursetid.Location = New System.Drawing.Point(207, 21)
        Me.cbocoursetid.Name = "cbocoursetid"
        Me.cbocoursetid.Size = New System.Drawing.Size(196, 30)
        Me.cbocoursetid.TabIndex = 17
        '
        'txtpunctuality
        '
        Me.txtpunctuality.Location = New System.Drawing.Point(207, 246)
        Me.txtpunctuality.Name = "txtpunctuality"
        Me.txtpunctuality.Size = New System.Drawing.Size(196, 30)
        Me.txtpunctuality.TabIndex = 11
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(20, 26)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(147, 25)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "Course   ID:"
        '
        'txtpreparation
        '
        Me.txtpreparation.Location = New System.Drawing.Point(207, 197)
        Me.txtpreparation.Name = "txtpreparation"
        Me.txtpreparation.Size = New System.Drawing.Size(196, 30)
        Me.txtpreparation.TabIndex = 10
        '
        'txtinteresting
        '
        Me.txtinteresting.Location = New System.Drawing.Point(207, 149)
        Me.txtinteresting.Name = "txtinteresting"
        Me.txtinteresting.Size = New System.Drawing.Size(196, 30)
        Me.txtinteresting.TabIndex = 9
        '
        'txtvoice
        '
        Me.txtvoice.Location = New System.Drawing.Point(207, 101)
        Me.txtvoice.Name = "txtvoice"
        Me.txtvoice.Size = New System.Drawing.Size(196, 30)
        Me.txtvoice.TabIndex = 8
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(20, 454)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(168, 22)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "8.Clear Explanation"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(20, 401)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 22)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "7.Fairness"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(20, 354)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(140, 22)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "6.Responsibility"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(20, 303)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(83, 22)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "5.Quality"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(20, 254)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 22)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "4.Punctuality"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 205)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(122, 22)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "3. Preparation"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(20, 157)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(107, 22)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "2.Interesting"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(20, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 22)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "1.Voice"
        '
        'btnsubmit
        '
        Me.btnsubmit.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsubmit.Location = New System.Drawing.Point(184, 630)
        Me.btnsubmit.Name = "btnsubmit"
        Me.btnsubmit.Size = New System.Drawing.Size(171, 51)
        Me.btnsubmit.TabIndex = 18
        Me.btnsubmit.Text = "Submit"
        Me.btnsubmit.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(481, 630)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(171, 51)
        Me.btnexit.TabIndex = 19
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Blue
        Me.Label12.Location = New System.Drawing.Point(55, 579)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(695, 48)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Please use number 1 to 10 to evaluate the course!Thank You"
        '
        'frmstudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 715)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btnsubmit)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmstudent"
        Me.Text = "Course Evaluation System"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtclearexplanation As TextBox
    Friend WithEvents txtfairness As TextBox
    Friend WithEvents txtresponsibility As TextBox
    Friend WithEvents txtquality As TextBox
    Friend WithEvents txtpunctuality As TextBox
    Friend WithEvents txtpreparation As TextBox
    Friend WithEvents txtinteresting As TextBox
    Friend WithEvents txtvoice As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents cbocoursetid As ComboBox
    Friend WithEvents btnsubmit As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents lbllecturerid As Label
    Friend WithEvents Label12 As Label
End Class
