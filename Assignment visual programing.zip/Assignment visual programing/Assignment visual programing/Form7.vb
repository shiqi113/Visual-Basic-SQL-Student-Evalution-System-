﻿Imports System.Data.OleDb
Public Class frmcourseevalution
    Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TAN SHI QI\Documents\Database1.accdb"

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Close()

    End Sub



    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loaddatabasetable()
    End Sub
    Private Sub loaddatabasetable()

        Dim cn As New OleDbConnection(connectionstring)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        cmd.CommandText = "SELECT MIN (Averagemark) AS 'MINIMUM MARK',MAX(Averagemark) AS 'MAXIMUM MARK',AVG(Averagemark) AS 'AVERAGE MARK', CourseID from Evaluation GROUP BY CourseID;"

        Dim dt As New DataTable With {.TableName = "Evaluation"}
        Try
            cn.Open()
            Dim ds As New DataSet
            Dim Evaluation As New DataTable With {.TableName = "Evaluation"}
            ds.Tables.Add(Evaluation)
            ds.Load(cmd.ExecuteReader(), LoadOption.OverwriteChanges, Evaluation)
            DataGridView1.DataSource = ds.Tables("Evaluation")


            cn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub
End Class