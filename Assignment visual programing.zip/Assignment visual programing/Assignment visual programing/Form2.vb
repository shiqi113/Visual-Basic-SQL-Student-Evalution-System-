﻿Public Class Frmadmin
    Private Sub LecturerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnulecturer.Click
        Dim b As New frmlecturer
        b.Show()
        Me.Show()
    End Sub

    Private Sub CourseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnucourse.Click
        Dim a As New frmcourse
        a.ShowDialog()
        Me.Show()

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
        Frmlogin.Show()

    End Sub


    Private Sub ReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnureport.Click

    End Sub

    Private Sub CourseToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles mnureportcourse.Click
        Dim c As New frmcourseevalution
        c.ShowDialog()
    End Sub

    Private Sub LecturerToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles mnureportlecturer.Click
        Dim d As New Frmlecturerevaluation
        d.ShowDialog()
    End Sub

    Private Sub Frmadmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


End Class
