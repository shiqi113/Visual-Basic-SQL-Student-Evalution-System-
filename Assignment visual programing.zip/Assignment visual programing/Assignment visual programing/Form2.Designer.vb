﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frmadmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnufile = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuprofile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnucourse = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnulecturer = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnureport = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnureportcourse = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnureportlecturer = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnufile, Me.mnuprofile, Me.mnureport})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 30)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnufile
        '
        Me.mnufile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.mnufile.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnufile.Name = "mnufile"
        Me.mnufile.Size = New System.Drawing.Size(54, 26)
        Me.mnufile.Text = "&File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(182, 26)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'mnuprofile
        '
        Me.mnuprofile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnucourse, Me.mnulecturer})
        Me.mnuprofile.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuprofile.Name = "mnuprofile"
        Me.mnuprofile.Size = New System.Drawing.Size(77, 26)
        Me.mnuprofile.Text = "&Profile"
        '
        'mnucourse
        '
        Me.mnucourse.Name = "mnucourse"
        Me.mnucourse.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.mnucourse.Size = New System.Drawing.Size(217, 26)
        Me.mnucourse.Text = "Course"
        '
        'mnulecturer
        '
        Me.mnulecturer.Name = "mnulecturer"
        Me.mnulecturer.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.B), System.Windows.Forms.Keys)
        Me.mnulecturer.Size = New System.Drawing.Size(217, 26)
        Me.mnulecturer.Text = "Lecturer"
        '
        'mnureport
        '
        Me.mnureport.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnureportcourse, Me.mnureportlecturer})
        Me.mnureport.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnureport.Name = "mnureport"
        Me.mnureport.Size = New System.Drawing.Size(76, 26)
        Me.mnureport.Text = "&Report"
        '
        'mnureportcourse
        '
        Me.mnureportcourse.Name = "mnureportcourse"
        Me.mnureportcourse.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnureportcourse.Size = New System.Drawing.Size(218, 26)
        Me.mnureportcourse.Text = "Course"
        '
        'mnureportlecturer
        '
        Me.mnureportlecturer.Name = "mnureportlecturer"
        Me.mnureportlecturer.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.mnureportlecturer.Size = New System.Drawing.Size(218, 26)
        Me.mnureportlecturer.Text = "Lecturer"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(234, 167)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(286, 46)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Welcome Admin"
        '
        'Frmadmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Frmadmin"
        Me.Text = "Course Evaluation System"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnufile As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mnuprofile As ToolStripMenuItem
    Friend WithEvents mnucourse As ToolStripMenuItem
    Friend WithEvents mnulecturer As ToolStripMenuItem
    Friend WithEvents mnureport As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents mnureportcourse As ToolStripMenuItem
    Friend WithEvents mnureportlecturer As ToolStripMenuItem
End Class
