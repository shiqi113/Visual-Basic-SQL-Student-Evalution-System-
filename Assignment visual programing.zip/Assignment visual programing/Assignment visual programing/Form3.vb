﻿Imports System.Data.OleDb
Public Class frmstudent
    Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TAN SHI QI\Documents\Database1.accdb"
    Public strUserId As String = ""
    Private Sub frmstudent_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadComboBoxData()
        MessageBox.Show("welcome" & vbTab & strUserId)

    End Sub
    Private Sub loadComboBoxData()
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "SELECT * FROM Course;"
                Try
                    cn.Open()

                    cmd.Connection = cn
                    Dim dr As OleDbDataReader = cmd.ExecuteReader

                    While dr.Read
                        cbocoursetid.Items.Add(dr.Item("CourseID"))

                    End While

                    cn.Close()

                Catch ex As Exception
                    MessageBox.Show(ex.ToString)
                End Try
            End Using
        End Using
    End Sub


    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Close()
        Frmlogin.Show()
    End Sub

    Private Sub btnsubmit_Click(sender As Object, e As EventArgs) Handles btnsubmit.Click

        Dim strcourseId As String = ""
        Dim voice As Integer = 0
        Dim interesting As Integer = 0
        Dim preparation As Integer = 0
        Dim punctuality As Integer = 0
        Dim quality As Integer = 0
        Dim responsibility As Integer = 0
        Dim fairness As Integer = 0
        Dim clearexplanation As Integer = 0
        Dim dbaverage As Double = 0.0
        Dim strlecturerid As String = ""

        strcourseId = cbocoursetid.SelectedItem
        strlecturerid = lbllecturerid.Text
        voice = CInt(txtvoice.Text)
        interesting = CInt(txtinteresting.Text)
        preparation = CInt(txtpreparation.Text)
        punctuality = CInt(txtpunctuality.Text)
        quality = CInt(txtquality.Text)
        responsibility = CInt(txtresponsibility.Text)
        fairness = CInt(txtfairness.Text)
        clearexplanation = CInt(txtclearexplanation.Text)
        dbaverage = (voice + interesting + preparation + punctuality + quality + responsibility + fairness + clearexplanation) / 8
        Dim cn As New OleDbConnection(connectionstring)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        cmd.CommandText = "INSERT INTO Evaluation (Voice, Interesting,Preparation,Punctuality,Quality,Responsibility
                    , Fairness,ClearExplanation, averagemark, CourseID,LecturerID,username) 
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"

        cmd.Parameters.AddWithValue("?", voice)
        cmd.Parameters.AddWithValue("?", interesting)
        cmd.Parameters.AddWithValue("?", preparation)
        cmd.Parameters.AddWithValue("?", punctuality)
        cmd.Parameters.AddWithValue("?", quality)
        cmd.Parameters.AddWithValue("?", responsibility)
        cmd.Parameters.AddWithValue("?", fairness)
        cmd.Parameters.AddWithValue("?", clearexplanation)
        cmd.Parameters.AddWithValue("?", dbaverage)
        cmd.Parameters.AddWithValue("?", strcourseId)
        cmd.Parameters.AddWithValue("?", strlecturerid)
        cmd.Parameters.AddWithValue("?", strUserId)



        Try
            cn.Open()
            cmd.ExecuteNonQuery()
            cn.Close()
            MessageBox.Show("Submit success")
        Catch ex As Exception
            MessageBox.Show("Error" & ex.ToString)
        End Try
    End Sub

    Private Sub cbosubjectid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbocoursetid.SelectedIndexChanged
        displayID()
    End Sub
    Private Sub displayID()

        Dim cn As New OleDbConnection(connectionstring)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        Dim strlecturerid As String = ""
        Dim storage As String
        storage = cbocoursetid.SelectedItem.ToString

        cmd.CommandText = "SELECT LecturerID FROM Course WHERE CourseID =?"
        Try
            cmd.Parameters.AddWithValue("?", cbocoursetid.SelectedItem)
            cn.Open()
            cmd.Connection = cn
            Dim dr As OleDbDataReader = cmd.ExecuteReader
            If dr.Read Then
                lbllecturerid.Text = dr.Item("LecturerID")
            End If
        Catch ex As Exception
        End Try
    End Sub
End Class