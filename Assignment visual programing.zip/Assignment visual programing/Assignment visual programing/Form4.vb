﻿Imports System.Data.OleDb
Public Class frmcourse
    Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TAN SHI QI\Documents\Database1.accdb"
    Private Sub frmadmindata_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loaddatabasetable()
        loadComboBoxData()
    End Sub
    Private Sub loadComboBoxData()
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "SELECT LecturerName FROM Lecturer;"
                Try
                    cn.Open()

                    cmd.Connection = cn
                    Dim dr As OleDbDataReader = cmd.ExecuteReader

                    While dr.Read
                        cbolecturername.Items.Add(dr.Item("LecturerName"))

                    End While

                    cn.Close()

                Catch ex As Exception
                    MessageBox.Show(ex.ToString)
                End Try
            End Using
        End Using
    End Sub
    Private Sub loaddatabasetable()
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "select * from Course;"
                Dim dt As New DataTable With {.TableName = "Course"}
                Try
                    cn.Open()
                    Dim ds As New DataSet
                    Dim coursetable As New DataTable With {.TableName = "Course"}
                    ds.Tables.Add(coursetable)
                    ds.Load(cmd.ExecuteReader(), LoadOption.OverwriteChanges, coursetable)
                    DataGridView1.DataSource = ds.Tables("Course")
                    DataGridView1.Columns("CourseID").Visible = True



                    cn.Close()

                Catch ex As Exception

                End Try
            End Using
        End Using
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "DELETE FROM Course WHERE CourseID = ?"
                cmd.Parameters.AddWithValue("?", txtcourseid.Text)
                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()

                Catch ex As Exception
                    MessageBox.Show("Error")
                    MessageBox.Show(ex.Message.ToString)
                End Try

                loaddatabasetable()
            End Using
        End Using
    End Sub
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Dim strlecturerid As String = ""
        strlecturerid = lbllecturerid.Text
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "INSERT INTO Course (CourseID, CourseName, LecturerName,LecturerID,Semester) 
                    VALUES (?,?,?,?,?)"
                cmd.Parameters.AddWithValue("?", txtcourseid.Text)
                cmd.Parameters.AddWithValue("?", txtcoursename.Text)
                cmd.Parameters.AddWithValue("?", cbolecturername.SelectedItem)
                cmd.Parameters.AddWithValue("?", strlecturerid)
                cmd.Parameters.AddWithValue("?", txtsemester.Text)
                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception
                    MessageBox.Show("Error")
                    MessageBox.Show(ex.ToString)
                End Try
                loaddatabasetable()
            End Using
        End Using
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Dim strlecturerid As String = ""
        strlecturerid = lbllecturerid.Text
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "UPDATE Course 
                    SET CourseName = ?, LecturerName = ? ,LecturerID=?,Semester =? WHERE CourseID = ?"
                cmd.Parameters.AddWithValue("?", txtcoursename.Text)
                cmd.Parameters.AddWithValue("?", cbolecturername.SelectedItem)
                cmd.Parameters.AddWithValue("?", strlecturerid)
                cmd.Parameters.AddWithValue("?", txtsemester.Text)
                cmd.Parameters.AddWithValue("?", txtcourseid.Text)

                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception
                    MessageBox.Show("Error")
                End Try
                loaddatabasetable()
            End Using
        End Using
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Dim cn As New OleDbConnection(connectionstring)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        cmd.CommandText = "SELECT * FROM Course WHERE CourseID=?;"
        Try
            cmd.Parameters.AddWithValue("?", txtcourseid.Text)
            cn.Open()
            cmd.Connection = cn

            Dim dr As OleDbDataReader = cmd.ExecuteReader
            If dr.Read Then
                txtcourseid.Text = dr.Item("CourseID")
                txtcoursename.Text = dr.Item("CourseName")
                txtsemester.Text = dr.Item("Semester")

            Else
                MessageBox.Show("invalid course id")

            End If

            cn.Close()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub cbosubjectid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbolecturername.SelectedIndexChanged
        displayID()
    End Sub
    Private Sub displayID()

        Dim cn As New OleDbConnection(connectionstring)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        Dim strlecturerid As String = ""
        Dim storage As String
        storage = cbolecturername.SelectedItem.ToString

        cmd.CommandText = "SELECT LecturerID FROM Lecturer WHERE LecturerName =?"
        Try
            cmd.Parameters.AddWithValue("?", cbolecturername.SelectedItem)
            cn.Open()
            cmd.Connection = cn
            Dim dr As OleDbDataReader = cmd.ExecuteReader
            If dr.Read Then
                lbllecturerid.Text = dr.Item("LecturerID")
            End If
        Catch ex As Exception
        End Try
    End Sub


End Class