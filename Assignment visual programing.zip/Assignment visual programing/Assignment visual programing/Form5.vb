﻿Imports System.Data.OleDb
Public Class frmlecturer
    Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TAN SHI QI\Documents\Database1.accdb"

    Private Sub frmlecturer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loaddatabasetable()
    End Sub
    Private Sub loaddatabasetable()
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "select * from Lecturer;"
                Dim dt As New DataTable With {.TableName = "Lecturer"}
                Try
                    cn.Open()
                    Dim ds As New DataSet
                    Dim Lecturertable As New DataTable With {.TableName = "Lecturer"}
                    ds.Tables.Add(Lecturertable)
                    ds.Load(cmd.ExecuteReader(), LoadOption.OverwriteChanges, Lecturertable)
                    DataGridView1.DataSource = ds.Tables("Lecturer")
                    DataGridView1.Columns("LecturerID").Visible = True



                    cn.Close()

                Catch ex As Exception

                End Try
            End Using
        End Using
    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "INSERT INTO Lecturer (lecturerID, lecturerName, LecturerEmail,LecturerPhone) 
                    VALUES (?,?,?,?)"
                cmd.Parameters.AddWithValue("?", txtlecturerID.Text)
                cmd.Parameters.AddWithValue("?", txtlecturername.Text)
                cmd.Parameters.AddWithValue("?", txtlectureremail.Text)
                cmd.Parameters.AddWithValue("?", txtlecturerphone.Text)
                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception
                    MessageBox.Show("Error")
                End Try
                loaddatabasetable()
            End Using
        End Using
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "UPDATE Lecturer 
                    SET LecturerName = ?, LecturerEmail = ? ,LecturerPhone =? WHERE LecturerID = ?"
                cmd.Parameters.AddWithValue("?", txtlecturername.Text)
                cmd.Parameters.AddWithValue("?", txtlectureremail.Text)
                cmd.Parameters.AddWithValue("?", txtlecturerphone.Text)
                cmd.Parameters.AddWithValue("?", txtlecturerID.Text)

                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()
                Catch ex As Exception
                    MessageBox.Show("Error")
                End Try
                loaddatabasetable()
            End Using
        End Using
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Using cn As New OleDbConnection(connectionstring)
            Using cmd As New OleDbCommand With {.Connection = cn}
                cmd.CommandText = "DELETE FROM Lecturer WHERE LecturerID = ?"
                cmd.Parameters.AddWithValue("?", txtlecturerID.Text)
                Try
                    cn.Open()
                    cmd.ExecuteNonQuery()
                    cn.Close()

                Catch ex As Exception
                    MessageBox.Show("Error")
                    MessageBox.Show(ex.Message.ToString)
                End Try

                loaddatabasetable()
            End Using
        End Using
    End Sub

    Private Sub btnclose_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub

    Private Sub btngo_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Dim cn As New OleDbConnection(connectionstring)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        cmd.CommandText = "SELECT * FROM Lecturer WHERE LecturerID=?;"
        Try
            cmd.Parameters.AddWithValue("?", txtlecturerID.Text)
            cn.Open()
            cmd.Connection = cn

            Dim dr As OleDbDataReader = cmd.ExecuteReader
            If dr.Read Then
                txtlecturerID.Text = dr.Item("LecturerID")
                txtlecturername.Text = dr.Item("LecturerName")
                txtlectureremail.Text = dr.Item("LecturerEmail")
                txtlecturerphone.Text = dr.Item("LecturerPhone")

            Else
                MessageBox.Show("invalid lecturer id")

            End If

            cn.Close()
        Catch ex As Exception

        End Try
    End Sub

End Class