﻿Imports System.Data.OleDb
Public Class Frmlogin
    Dim connectionstring As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\TAN SHI QI\Documents\Database1.accdb"

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
    End Sub

    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnreset.Click
        txtpassword.Text = ""
        txtusername.Text = ""

    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Dim cn As New OleDbConnection(connectionstring)
        Dim cmd As New OleDbCommand With {.Connection = cn}
        cmd.CommandText = "SELECT * FROM LoginTable
                    WHERE username = ? AND password = ?;"

        If txtusername.Text = "admin" And txtpassword.Text = "88888888" Then
            Dim frm1 As New Frmadmin
            frm1.Show()
            Me.Hide()
        Else
            Try
                cmd.Parameters.AddWithValue("?", txtusername.Text)
                cmd.Parameters.AddWithValue("?", txtpassword.Text)
                cn.Open()

                cmd.Connection = cn
                Dim dr As OleDbDataReader = cmd.ExecuteReader

                If dr.Read Then
                    Dim frm3 As New frmstudent
                    frm3.strUserid = txtusername.Text
                    frm3.Show()
                    Me.Hide()
                Else
                    MessageBox.Show("Invalid username and password")
                End If

                cn.Close()

            Catch ex As Exception

                MessageBox.Show(ex.ToString)
            End Try
        End If


    End Sub

    Private Sub Frmlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
